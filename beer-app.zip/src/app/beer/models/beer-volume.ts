export interface BeerVolume {
    value: number;
    unit: string;
}
