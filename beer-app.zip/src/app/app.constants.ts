export const API_ENDPOINT = 'https://api.punkapi.com/v2/';

