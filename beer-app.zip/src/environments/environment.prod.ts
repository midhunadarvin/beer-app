export const environment = {
  production: true,
  apiEndpoint: 'http://starlord.hackerearth.com/beercraft'
};
